package com.example.burritoapp;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.CheckBox;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {
    TextView priceTextView;
    TextView orderTextView;

    CheckBox LettuceCheckBox;
    CheckBox TomatoCheckBox;
    CheckBox SpinachCheckBox;
    CheckBox CornCheckBox;

    CheckBox BrownRiceCheckBox;
    CheckBox BlackBeansCheckBox;
    CheckBox WhiteRiceCheckBox;
    CheckBox RedBeansCheckBox;

    CheckBox ChickenCheckBox;
    CheckBox PorkCheckBox;
    CheckBox SteakCheckBox;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        priceTextView = findViewById(R.id.priceTextView);
        orderTextView = findViewById(R.id.orderTextView);

        LettuceCheckBox = findViewById(R.id.LettuceCheckBox);
        TomatoCheckBox = findViewById(R.id.TomatoCheckBox);
        SpinachCheckBox = findViewById(R.id.SpinachCheckBox);
        CornCheckBox = findViewById(R.id.CornCheckBox);

        BrownRiceCheckBox = findViewById(R.id.BrownRiceCheckBox);
        BlackBeansCheckBox = findViewById(R.id.BlackBeansCheckBox);
        WhiteRiceCheckBox = findViewById(R.id.WhiteRiceCheckBox);
        RedBeansCheckBox = findViewById(R.id.RedBeansCheckBox);

        ChickenCheckBox = findViewById(R.id.ChickenCheckBox);
        PorkCheckBox = findViewById(R.id.PorkCheckBox);
        SteakCheckBox = findViewById(R.id.SteakCheckBox);
    }

    public void checkOrder(View view) {
        String myOrder = "";
        myOrder = "";

        double price = 4.95;

        if (LettuceCheckBox.isChecked()){
            myOrder += " Lettuce";
        }

        if (TomatoCheckBox.isChecked()){
            myOrder += "  \nTomato";
        }
        if (SpinachCheckBox.isChecked()){
            myOrder += " Spinach";
        }

        if (CornCheckBox.isChecked()){
            myOrder += " Corn";
            price = price + 1.00;
        }

        if (BrownRiceCheckBox.isChecked()){
            myOrder += "\n Brown Rice";
        }

        if (BlackBeansCheckBox.isChecked()){
            myOrder += " \n Black Beans";
        }

        if (WhiteRiceCheckBox.isChecked()){
            myOrder +=" \n White Rice";
        }

        if (RedBeansCheckBox.isChecked()){
            myOrder +=" \n Red Beans";
            price = price + 1.00;
        }

        if (ChickenCheckBox.isChecked()){
            myOrder +="\n Chicken";
            price = price + 1.00;
        }

        if (PorkCheckBox.isChecked()){
            myOrder +="\n Pork";
            price = price + 1.00;
        }

        if (SteakCheckBox.isChecked()){
            myOrder +="\n Steak";
            price = price + 2.00;
        }

        String totalPrice = Double.toString(price);

        orderTextView.setText(myOrder);
        priceTextView.setText(String.format("$"+ totalPrice));
    }
}