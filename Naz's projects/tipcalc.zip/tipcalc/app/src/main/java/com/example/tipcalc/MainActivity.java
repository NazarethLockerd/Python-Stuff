package com.example.tipcalc;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    private EditText totalBillEditText;
    private TextView finalBillTextView;

    double bill;
    double tip;
    double tax = 0.07;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        totalBillEditText = findViewById(R.id.totalBillEditText);
        finalBillTextView = findViewById(R.id.finalBillTextView);
    }


    public void fivebutton(View view) {

        try {
            bill = Integer.parseInt(totalBillEditText.getText().toString());
            tip = (bill*(1 + tax))*0.15;
        } catch (NumberFormatException e) {
            //e.printStackTrace();
            Toast.makeText(this, "Please enter a value", Toast.LENGTH_SHORT).show();
        } finally {
            String finalResult = new Double(bill + tip).toString();
            finalBillTextView.setText("$"+finalResult);
        }


    }

    public void eightbutton(View view) {

        try {
            bill = Integer.parseInt(totalBillEditText.getText().toString());
            tip = (bill*(1 + tax))*0.18;
        } catch (NumberFormatException e) {
            //e.printStackTrace();
            Toast.makeText(this, "Please enter a value", Toast.LENGTH_SHORT).show();
        } finally {
            String finalResult = new Double(bill + tip).toString();
            finalBillTextView.setText("$"+finalResult);
        }
    }

    public void twentybutton(View view) {

        try {
            bill = Integer.parseInt(totalBillEditText.getText().toString());
            tip = (bill*(1 + tax))*0.20;
        } catch (NumberFormatException e) {
            //e.printStackTrace();
            Toast.makeText(this, "Please enter a value", Toast.LENGTH_SHORT).show();
        } finally {
            String finalResult = new Double(bill + tip).toString();
            finalBillTextView.setText("$"+finalResult);
        }
    }


        }


